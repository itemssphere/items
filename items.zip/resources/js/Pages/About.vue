<script setup>
import { Head } from '@inertiajs/inertia-vue3';
import FrontPage from '@/Layouts/FrontPage.vue'
</script>
<template>
    <Head title="About Page" />
    <FrontPage>
        <div class="about-page">
            <div class="container">
                <ul class="page__navigation--links d-none d-lg-flex">
                    <li class="page__navigation--link regular">
                        <a href="">Home</a>
                    </li>
                    <li class="page__navigation--link regular">
                        >
                        <a href="">Home</a>
                    </li>
                </ul>

                <div class="col-6 col-lg-12">
                    <div class="page__title bold">
                        About
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="about-page__context">
                            <h1 class="about-page__context--title bold">OUR MISSION</h1>
                            <br />
                            <div class="d-flex align-items-start">
                                <img src="/assets/img/svg/quote-left.svg" alt="" class="about-page__context--icon">
                                <div class="about-page__context--desc head italic">
                                    The NES Classic Edition system is a miniaturized version of the groundbreaking NES, originally released in 1985.  Just plug the NES Classic Edition into your TV, pick up that gray controller, and rediscover the joy of NES games.

        Play NES games the way they’re meant to be played—with a full-size «original» controller. 
        The included NES Classic Controller can also be used with NES Virtual Console games on your Wii™ or Wii U™ console by connecting it to a Wii Remote™ controller.

        Pick up right where you left off with four Suspend Point slots for each game. Just press the Reset button while playing to return to the HOME menu and save your progress to a slot. Have a perfect run going? You can lock your save file and resume at a later time so there’s no danger of losing your progress.
                                </div>
                            </div>
                        </div>
                        <h1 class="about-page__context--title bold">We are …</h1>
                        <div class="about-page__context--desc body regular">
                            The NES Classic Edition system is a miniaturized version of the groundbreaking NES, originally released in 1985.  Just plug the NES Classic Edition into your TV, pick up that gray controller, and rediscover the joy of NES games.

        Play NES games the way they’re meant to be played—with a full-size «original» controller. 
        The included NES Classic Controller can also be used with NES Virtual Console games on your Wii™ or Wii U™ console by connecting it to a Wii Remote™ controller.

        Pick up right where you left off with four Suspend Point slots for each game. Just press the Reset button while playing to return to the HOME menu and save your progress to a slot. Have a perfect run going? You can lock your save file and resume at a later time so there’s no danger of losing your progress.
                        </div>
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="about-page__context block">
                                    <h1 class="about-page__context--title bold">Social Programs</h1>
                                    <h1 class="about-page__context--big-title bold">Buy and help others</h1>
                                    <div class="about-page__context--desc regular">
                                        The NES Classic Edition system is a miniaturized version of the groundbreaking NES, originally released in 1985.  Just plug the NES Classic Edition into your TV, pick up that gray controller, and rediscover the joy of NES games.

        Play NES games the way they’re meant to be played—with a full-size «original» controller. 
        The included NES Classic Controller can also be used with NES Virtual Console games on your Wii™ or Wii U™ console by connecting it to a Wii Remote™ controller.

        Pick up right where you left off with four Suspend Point slots for each game. Just press the Reset button while playing to return to the HOME menu and save your progress to a slot. Have a perfect run going? You can lock your save file and resume at a later time so there’s no danger of losing your progress.
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="about-page__context block">
                                    <h1 class="about-page__context--title bold">Social Programs</h1>
                                    <h1 class="about-page__context--big-title bold">Buy and help others</h1>
                                    <div class="about-page__context--desc regular">
                                        The NES Classic Edition system is a miniaturized version of the groundbreaking NES, originally released in 1985.  Just plug the NES Classic Edition into your TV, pick up that gray controller, and rediscover the joy of NES games.

        Play NES games the way they’re meant to be played—with a full-size «original» controller. 
        The included NES Classic Controller can also be used with NES Virtual Console games on your Wii™ or Wii U™ console by connecting it to a Wii Remote™ controller.

        Pick up right where you left off with four Suspend Point slots for each game. Just press the Reset button while playing to return to the HOME menu and save your progress to a slot. Have a perfect run going? You can lock your save file and resume at a later time so there’s no danger of losing your progress.
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="about-page__context block">
                                    <h1 class="about-page__context--title bold">Charity</h1>
                                    <h1 class="about-page__context--big-title bold">Donate</h1>
                                    <div class="about-page__context--desc regular">
                                        The NES Classic Edition system is a miniaturized version of the groundbreaking NES, originally released in 1985.  Just plug the NES Classic Edition into your TV, pick up that gray controller, and rediscover the joy of NES games.

        Play NES games the way they’re meant to be played—with a full-size «original» controller. 
        The included NES Classic Controller can also be used with NES Virtual Console games on your Wii™ or Wii U™ console by connecting it to a Wii Remote™ controller.

        Pick up right where you left off with four Suspend Point slots for each game. Just press the Reset button while playing to return to the HOME menu and save your progress to a slot. Have a perfect run going? You can lock your save file and resume at a later time so there’s no danger of losing your progress.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <h1 class="about-page__context--title partner-title bold d-block">Our partners</h1>
                        <ul class="ourshop d-flex flex-row flex-wrap flex-lg-nowrap">
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/alta.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/ee.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/zoomer.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="img/samsung.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>

                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/alta.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/alta.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/ee.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                            <li class="ourshop__item">
                                <a href="" class="ourshop__item--link">
                                    <img src="/assets/img/zoomer.png" alt="" class="ourshop__item--img">
                                </a>
                            </li>
                        </ul>
                        <div class="col-12">
                            <div class="page__navigation d-flex justify-content-center">
                                <button class="page__navigation--btn bold">More</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </FrontPage>
</template>FrontPage