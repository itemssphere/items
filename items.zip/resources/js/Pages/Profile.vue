FrontPage<script setup>
import { Head } from '@inertiajs/inertia-vue3';
import FrontPage from '@/Layouts/FrontPage.vue'
</script>
<template>
    <Head title="Social Page" />
    <FrontPage>
        <span>Social</span>
    </FrontPage>
</template>