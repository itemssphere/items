<script setup>
import { Head } from '@inertiajs/inertia-vue3';
import FrontPage from '@/Layouts/FrontPage.vue'
</script>
<template>
    <Head title="Cart Page" />
    <FrontPage>
        <span>Cart</span>
    </FrontPage>
</template>