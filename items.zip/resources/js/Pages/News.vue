<script setup>
import { Head } from '@inertiajs/inertia-vue3'
import FrontPage from '@/Layouts/FrontPage.vue'
</script>
<template>
    <Head title="News Page" />
    <FrontPage>
        <div class="news-page">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <ul class="page__navigation--links d-flex">
                            <li class="page__navigation--link regular">
                                <a href="">Home</a>
                            </li>
                            <li class="page__navigation--link regular">
                                >
                                <a href="">Home</a>
                            </li>
                        </ul>
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="page__title regular">
                                News
                            </div>
                            <div class="d-block d-lg-none">
                                <button>
                                    choose categories
                                </button>
                            </div>
                        </div>
                    </div>
                    <!-- left -->
                    <div class="col-12 col-lg-8">
                        <div class="news news-page__item">
                            <div class="news__item d-flex flex-column">
                                <figure class="news-page__item--img">
                                    <img src="/assets/img/news.png" alt="">
                                </figure>
                                <div>
                                    <p class="news__item--date regular">
                                        01/06/2021 <a href="" class="news-page__item--data-category">category</a>
                                    </p>
                                    <h1 class="news__item--title news-page__item--title bold">
                                        Elit Electronics Is Going To Joined Itemssphere 
                                        With Most Highest Percentage OF CHARITY
                                    </h1>
                                    <div class="news__item--desc regular">
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt nisi rem quo, nam atque tenetur dignissimos excepturi quas molestias, vero nulla alias. Nulla, quam natus. Nam, incidunt! Voluptate, debitis ducimus!
                                    </div>
                                    <div class="news-page__item--footer d-flex align-items-center">
                                        <a href="" class="news-page__item--btn bold">read more</a>
                                        <div class="news-page__item--soc d-flex align-items-center">
                                            <div class="news-page__item--soc-icon d-flex align-items-center justify-content-center">
                                                <img src="/assets/img/svg/like.svg" alt="">
                                            </div>
                                            <span class="news-page__item--soc-text regular">25</span>
                                        </div>
                                        <div class="news-page__item--soc d-flex align-items-center">
                                            <div class="d-flex align-items-center justify-content-center">
                                                <img src="/assets/img/svg/timer-line.svg" alt="">
                                            </div>
                                            <span class="news-page__item--soc-text regular">6 min read</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- item end -->
                        <div class="news news-page__item">
                            <div class="news__item d-flex flex-column">
                                <figure class="news-page__item--img">
                                    <img src="/assets/img/news.png" alt="">
                                </figure>
                                <div>
                                    <p class="news__item--date regular">
                                        01/06/2021 <a href="" class="news-page__item--data-category">category</a>
                                    </p>
                                    <h1 class="news__item--title news-page__item--title bold">
                                        Elit Electronics Is Going To Joined Itemssphere 
                                        With Most Highest Percentage OF CHARITY
                                    </h1>
                                    <div class="news__item--desc regular">
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt nisi rem quo, nam atque tenetur dignissimos excepturi quas molestias, vero nulla alias. Nulla, quam natus. Nam, incidunt! Voluptate, debitis ducimus!
                                    </div>
                                    <div class="news-page__item--footer d-flex align-items-center">
                                        <a href="" class="news-page__item--btn bold">read more</a>
                                        <div class="news-page__item--soc d-flex align-items-center">
                                            <div class="news-page__item--soc-icon d-flex align-items-center justify-content-center">
                                                <img src="/assets/img/svg/like.svg" alt="">
                                            </div>
                                            <span class="news-page__item--soc-text regular">25</span>
                                        </div>
                                        <div class="news-page__item--soc d-flex align-items-center">
                                            <div class="d-flex align-items-center justify-content-center">
                                                <img src="/assets/img/svg/timer-line.svg" alt="">
                                            </div>
                                            <span class="news-page__item--soc-text regular">6 min read</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- item end -->
                    </div><!-- end -->
                    <!-- right -->
                    <div class="col-12 col-lg-4">
                        <!-- news desktop version -->
                        <div class="news news__categories d-none d-lg-block">
                            <h2 class="products__section--text regular">Categories</h2>
                            <ul class="news__categories--list d-flex flex-wrap">
                                <li class="news__categories--item">
                                    <a href="" class="news__categories--link regular">
                                        Shops (23)
                                    </a>
                                </li>
                                <li class="news__categories--item">
                                    <a href="" class="news__categories--link regular">
                                        Products (23)
                                    </a>
                                </li>
                                <li class="news__categories--item">
                                    <a href="" class="news__categories--link regular active">
                                        Shops (23)
                                    </a>
                                </li>
                                <li class="news__categories--item">
                                    <a href="" class="news__categories--link regular">
                                        Products (23)
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <ul class="news d-none d-lg-block">
                            <h2 class="products__section--text regular">Latest news</h2>
                            <li class="d-flex">
                                <a href="" class="news__item d-flex">
                                    <figure class="news__item--img">
                                        <img src="/assets/img/news.png" alt="">
                                    </figure>
                                    <div class="news__item--text">
                                        <h1 class="news__item--title bold">
                                            Elit Electronics Is Going To Joined Itemssphere 
                                            With Most Highest Percentage OF CHARITY
                                        </h1>
                                        <div class="news__item--desc regular">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt nisi rem quo, nam atque tenetur dignissimos excepturi quas molestias, vero nulla alias. Nulla, quam natus. Nam, incidunt! Voluptate, debitis ducimus!
                                        </div>
                                        <p class="news__item--date regular">
                                            01/06/2021
                                        </p>
                                    </div>
                                </a>
                            </li>
                            <li class="d-flex">
                                <a href="" class="news__item d-flex">
                                    <figure class="news__item--img">
                                        <img src="/assets/img/news.png" alt="">
                                    </figure>
                                    <div class="news__item--text">
                                        <h1 class="news__item--title bold">
                                            Elit Electronics Is Going To Joined Itemssphere 
                                            With Most Highest Percentage OF CHARITY
                                        </h1>
                                        <div class="news__item--desc regular">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt nisi rem quo, nam atque tenetur dignissimos excepturi quas molestias, vero nulla alias. Nulla, quam natus. Nam, incidunt! Voluptate, debitis ducimus!
                                        </div>
                                        <p class="news__item--date regular">
                                            01/06/2021
                                        </p>
                                    </div>
                                </a>
                            </li>
                            <li class="d-flex">
                                <a href="" class="news__item d-flex">
                                    <figure class="news__item--img">
                                        <img src="/assets/img/news.png" alt="">
                                    </figure>
                                    <div class="news__item--text">
                                        <h1 class="news__item--title bold">
                                            Elit Electronics Is Going To Joined Itemssphere 
                                            With Most Highest Percentage OF CHARITY
                                        </h1>
                                        <div class="news__item--desc regular">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt nisi rem quo, nam atque tenetur dignissimos excepturi quas molestias, vero nulla alias. Nulla, quam natus. Nam, incidunt! Voluptate, debitis ducimus!
                                        </div>
                                        <p class="news__item--date regular">
                                            01/06/2021
                                        </p>
                                    </div>
                                </a>
                            </li>
                            <li class="d-flex">
                                <a href="" class="news__item d-flex">
                                    <figure class="news__item--img">
                                        <img src="/assets/img/news.png" alt="">
                                    </figure>
                                    <div class="news__item--text">
                                        <h1 class="news__item--title bold">
                                            Elit Electronics Is Going To Joined Itemssphere 
                                            With Most Highest Percentage OF CHARITY
                                        </h1>
                                        <div class="news__item--desc regular">
                                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Deserunt nisi rem quo, nam atque tenetur dignissimos excepturi quas molestias, vero nulla alias. Nulla, quam natus. Nam, incidunt! Voluptate, debitis ducimus!
                                        </div>
                                        <p class="news__item--date regular">
                                            01/06/2021
                                        </p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <div class="d-block d-lg-none">
                            mobile slider
                        </div>
                    </div><!-- end -->
                </div>
            </div>
        </div>
    </FrontPage>
</template>