<script setup>
/** Components */
import { Head } from "@inertiajs/inertia-vue3";
import FrontPage from "@/Layouts/FrontPage.vue";
</script>
<!-- Home Page Template -->
<template>
  <Head title="Privacy Policy" />
  <FrontPage>
    <div class="about-page">
      <div class="container">
        <ul class="page__navigation--links d-flex">
          <li class="page__navigation--link regular">
            <a href="">Home</a>
          </li>
          <li class="page__navigation--link regular">
            >
            <a href="">Home</a>
          </li>
        </ul>
        <div class="page__title regular">Agreement</div>
        <div class="row">
          <div class="col-12">
            <h1 class="about-page__context--title bold">Pirveli</h1>
            <div class="about-page__context--desc">
              The NES Classic Edition system is a miniaturized version of the
              groundbreaking NES, originally released in 1985. Just plug the NES
              Classic Edition into your TV, pick up that gray controller, and
              rediscover the joy of NES games. Play NES games the way they’re
              meant to be played—with a full-size «original» controller. The
              included NES Classic Controller can also be used with NES Virtual
              Console games on your Wii™ or Wii U™ console by connecting it to a
              Wii Remote™ controller. Pick up right where you left off with four
              Suspend Point slots for each game. Just press the Reset button
              while playing to return to the HOME menu and save your progress to
              a slot. Have a perfect run going? You can lock your save file and
              resume at a later time so there’s no danger of losing your
              progress.
            </div>
            <br />
            <h1 class="about-page__context--title bold">More</h1>
            <div class="about-page__context--desc">
              The NES Classic Edition system is a miniaturized version of the
              groundbreaking NES, originally released in 1985. Just plug the NES
              Classic Edition into your TV, pick up that gray controller, and
              rediscover the joy of NES games. Play NES games the way they’re
              meant to be played—with a full-size «original» controller. The
              included NES Classic Controller can also be used with NES Virtual
              Console games on your Wii™ or Wii U™ console by connecting it to a
              Wii Remote™ controller. Pick up right where you left off with four
              Suspend Point slots for each game. Just press the Reset button
              while playing to return to the HOME menu and save your progress to
              a slot. Have a perfect run going? You can lock your save file and
              resume at a later time so there’s no danger of losing your
              progress.
            </div>
          </div>
        </div>
      </div>
    </div>
  </FrontPage>
</template>