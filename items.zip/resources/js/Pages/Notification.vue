<script setup>
import { Head } from '@inertiajs/inertia-vue3';
import FrontPage from '@/Layouts/FrontPage.vue'
</script>
<template>
    <Head title="Notification Page" />
    <FrontPage>
        <span>Notification</span>
    </FrontPage>
</template>