<script setup>
import { Head } from '@inertiajs/inertia-vue3'
import FrontPage from '@/Layouts/FrontPage.vue'
</script>
<template>
    <Head title="Market Page" />
    <FrontPage>
        <section class="touch market-touch">
            
            <!-- categories, main slider, banner -->
            <div class="container">
                <div class="row">
                    <div class="col d-none d-lg-block js-filter" style="max-width: 275px;">
                        <div class="active-filter--container">

                            <div class="categories categories__shop d-none d-lg-block">
                                <h2 class="categories--title regular">Categories</h2>
                                <ul class="categories__list">
                                    <li class="categories__list--item">
                                        <a href="" class="categories__list--link regular">Agriculture & Food</a>
                                    </li>
                                    <li class="categories__list--item">
                                        <a href="" class="categories__list--link regular">Auto & Transportation</a>
                                    </li>
                                    <li class="categories__list--item">
                                        <a href="" class="categories__list--link regular">Clothing, Shoes & Accessories</a>
                                    </li>
                                    <li class="categories__list--item">
                                        <a href="" class="categories__list--link regular">Packaging, Advertising & Office</a>
                                    </li>
                                    <li class="categories__list--item">
                                        <a href="" class="categories__list--link regular">Agriculture & Food</a>
                                    </li>
                                </ul>
                            </div>

                            <div class="categories categories-filter categories__shop d-flex flex-column">
                                <div class="categories-filter__form d-flex justify-content-between align-items-center">
                                    <h2 class="categories--title regular">Filters</h2>
                                    <button class="categories-filter__clear delete-filter active d-flex align-items-center regular">
                                        <p class="d-none d-lg-block">Clear</p>
                                        <img src="/assets/img/svg/clear-bold.svg" alt="" class="convert-svg">    
                                    </button>
                                </div><!-- end -->
                                
                                <div class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Review:</h2>
                                        <button class="categories-filter__clear active d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <div class="d-flex justify-content-start">
                                        <div class="products-slider__item--stars--item categories-filter__rating products-slider__item--stars--item--active"></div>
                                        <div class="products-slider__item--stars--item categories-filter__rating products-slider__item--stars--item--active"></div>
                                        <div class="products-slider__item--stars--item categories-filter__rating products-slider__item--stars--item--active"></div>
                                        <div class="products-slider__item--stars--item categories-filter__rating products-slider__item--stars--item--active"></div>
                                        <div class="products-slider__item--stars--item categories-filter__rating"></div>
                                    </div>
                                </div><!-- end -->
                                
                                <form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Price range:</h2>
                                        <button class="categories-filter__clear active d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <!-- input -->
                                        <div class="categories-filter__form--min-max d-flex align-items-center">
                                            <label class="min-max__label">
                                                <input type="text" class="min-max__label--input h-roman" placeholder="min" value="">
                                            </label>
                                            <label class="min-max__label">
                                                <input type="text" class="min-max__label--input h-roman" placeholder="max" value="">
                                            </label>
                                        </div>
                                        <button class="min-max--btn reguylar">
                                            Ok
                                        </button>
                                    </div>
                                </form>
                                <form form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Price off:</h2>
                                        <button class="categories-filter__clear d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <div class="categories-filter__pracent regular d-flex flex-column align-items-start">
                                        <div class="categories-filter__ratings d-flex justify-content-between">
                                            <div class="active">5%</div>
                                            <div class="active">15%</div>
                                            <div class="">25%</div>
                                            <div class="">50%</div>
                                        </div>
                                    </div><!-- end -->
                                </form><!-- end -->

                                <!-- <form class="categories-filter__form">
                                    <div class="select">
                                        <h1 class="select__title regular">Choose shipping type:</h1>
                                        <select name="" id="" class="select__list regular">
                                            <option value="" class="select__list--item">Delivery</option>
                                            <option value="" class="select__list--item">erti</option>
                                            <option value="" class="select__list--item">ori</option>
                                        </select>
                                    </div>
                                    <div class="select">
                                        <h1 class="select__title regular">Location:</h1>
                                        <select name="" id="" class="select__list regular">
                                            <option value="" class="select__list--item">Tbilisi</option>
                                            <option value="" class="select__list--item">erti</option>
                                            <option value="" class="select__list--item">ori</option>
                                        </select>
                                    </div>
                                </form> -->
                            
                                <form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Shops</h2>
                                        <button class="categories-filter__clear d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Full Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name Name 
                                        </span>
                                    </label><!-- end -->
                                    <a href="" class="categories-filter--all-btn d-flex justify-content-end regular">View all</a>
                                </form>

                                <form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Brands</h2>
                                        <button class="categories-filter__clear d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <div class="categories-filter__form--search d-flex align-items-center justify-content-between">
                                        <input type="text" class="regular" style="width: 100%;">
                                        <button>
                                            <img src="/assets/img/svg/filter-loog.svg" alt="" class="convert-svg">
                                        </button>
                                    </div>
                                    <div class="categories-filter__form--search-list">
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                        <!-- checkbox -->
                                        <label class="element__check d-flex align-items-center">
                                            <div>
                                                <input type="checkbox" class="element__check--input">
                                                <span class="element__check--checked">
                                                    <img src="/assets/img/svg/checked.svg" alt="">
                                                </span>
                                            </div>
                                            <span class="element__check--text regular">
                                                Name
                                            </span>
                                        </label><!-- end -->
                                    </div>
                                    <a href="" class="categories-filter--all-btn d-flex justify-content-end regular">View all</a>
                                </form>

                                <form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Shops</h2>
                                        <button class="categories-filter__clear d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Full Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name Name 
                                        </span>
                                    </label><!-- end -->
                                    <a href="" class="categories-filter--all-btn d-flex justify-content-end regular">View all</a>
                                </form>

                                <form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Charities</h2>
                                        <button class="categories-filter__clear d-flex align-items-center regular">
                                            Clear
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                        </button>
                                    </div>
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Full Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name Name 
                                        </span>
                                    </label><!-- end -->
                                    <a href="" class="categories-filter--all-btn d-flex justify-content-end regular">View all</a>
                                </form>
                            </div><!-- end -->

                            <div class="categories categories-filter categories__shop">
                                <div class="categories-filter__form d-flex justify-content-between align-items-center">
                                    <h2 class="categories--title regular">Filters</h2>
                                    <button class="categories-filter__clear active d-flex align-items-center regular">
                                        <p class="d-none d-lg-block">Clear</p>
                                        <img src="/assets/img/svg/clear-bold.svg" alt="" class="convert-svg">    
                                    </button>
                                </div><!-- end -->
                                
                                <form class="categories-filter__form">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <h2 class="select__title bold">Charities</h2>
                                        <button class="categories-filter__clear d-flex align-items-center regular">
                                            <img src="/assets/img/svg/filter-clear-gray.svg" alt="" class="convert-svg">    
                                            Clear
                                        </button>
                                    </div>
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Full Name
                                        </span>
                                    </label><!-- end -->
                                    <!-- checkbox -->
                                    <label class="element__check d-flex align-items-center">
                                        <div>
                                            <input type="checkbox" class="element__check--input">
                                            <span class="element__check--checked">
                                                <img src="/assets/img/svg/checked.svg" alt="">
                                            </span>
                                        </div>
                                        <span class="element__check--text regular">
                                            Name Name 
                                        </span>
                                    </label><!-- end -->
                                    <a href="" class="categories-filter--all-btn d-flex justify-content-end regular">View all</a>
                                </form>
                            </div><!-- end -->
                        </div>
                    </div><!-- left -->
                    <div class="col">
                        <div class="row">
                            <div class="col-12 d-none d-lg-block">
                                <ul class="page__navigation--links d-flex">
                                    <li class="page__navigation--link regular">
                                        <a href="">Home</a>
                                    </li>
                                    <li class="page__navigation--link regular">
                                        >
                                        <a href="">Home</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-6 col-lg-12">
                                <div class="page__title bold">
                                    Products <span class="regular">60,000</span>
                                </div>
                            </div>
                            <div class="col-6 col-lg-12 d-block">
                                <div class="product-filter">
                                    <div class="row">
                                        <div class="col-3 d-none d-lg-block">
                                            <div class="product-filter__item d-flex align-items-start flex-column justify-content-start">
                                                <p class="product-filter__item--title regular">Sort by product type:</p>
                                                <ul class="product-filter__item--categories regular d-flex">
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link active">All</a>
                                                    </li>
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link">New</a>
                                                    </li>
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link">Used</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- end -->
                                        <div class="col-3 d-none d-lg-block">
                                            <div class="product-filter__item d-flex align-items-start flex-column justify-content-start">
                                                <p class="product-filter__item--title regular">Sort by product type:</p>
                                                <ul class="product-filter__item--categories regular d-flex">
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link">All</a>
                                                    </li>
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link green">Free</a>
                                                    </li>
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link active">Donate</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- end -->
                                        <div class="col-3 d-none d-lg-block">
                                            <div class="product-filter__item d-flex align-items-start flex-column justify-content-start">
                                                <p class="product-filter__item--title regular">Sort by product type:</p>
                                                <ul class="product-filter__item--categories regular d-flex">
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link">All</a>
                                                    </li>
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link">New</a>
                                                    </li>
                                                    <li class="product-filter__item--categori">
                                                        <a href="" class="product-filter__item--link active">Free size Big </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- end -->
                                        <div class="col-12 col-lg-3">
                                            <div class="product-filter__item  d-flex flex-lg-column justify-content-end">
                                                <p class="product-filter__item--title regular">Sort by</p>
                                                <!-- select -->
                                                <div class="select">
                                                    <select name="" id="" class="select__list regular">
                                                        <option value="" class="select__list--item">Delivery</option>
                                                        <option value="" class="select__list--item">erti</option>
                                                        <option value="" class="select__list--item">ori</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div><!-- end -->
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-xl-3 col-6">
                                <div class="products-slider__item shop__item">
                                    <button class="products-slider__item--fav"><img src="/assets/img/svg/product-fav.svg" alt=""></button>
                                    <!-- item slider -->
                                    <div class="item-slider__item">
                                        <img src="/assets/img/watch.png" alt="">
                                    </div>
                                    <div class="products-slider__item--footer d-flex flex-column align-items-start">
                                        <div class="products-slider__item--status regular">
                                            NEW
                                        </div>
                                        <div class="products-slider__item--price bold">
                                            ₾1,239.39
                                        </div>
                                        <a href="" class="products-slider__item--name regular">
                                            TCL 40S325 40 Inch 1080p Smart LED Roku TV
                                        </a>
                                        <div class="products-slider__item--stars regular d-flex align-items-center">
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item"></div>
                                            <span>132 review</span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end -->
                            <div class="col-lg-4 col-xl-3 col-6">
                                <div class="products-slider__item shop__item">
                                    <button class="products-slider__item--fav"><img src="/assets/img/svg/product-fav.svg" alt="" class="convert-svg"></button>
                                    <!-- item slider -->
                                    <div class="item-slider__item">
                                        <img src="/assets/img/watch.png" alt="">
                                    </div>
                                    <div class="products-slider__item--footer d-flex flex-column align-items-start">
                                        <div class="products-slider__item--status regular">
                                            NEW
                                        </div>
                                        <div class="products-slider__item--price bold">
                                            ₾1,239.39
                                        </div>
                                        <a href="" class="products-slider__item--name regular">
                                            TCL 40S325 40 Inch 1080p Smart LED Roku TV
                                        </a>
                                        <div class="products-slider__item--stars regular d-flex align-items-center">
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                                            <div class="products-slider__item--stars--item"></div>
                                            <span>132 review</span>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- end -->

                            <div class="col-12">
                                <div class="page__navigation d-flex justify-content-center">
                                    <button class="page__navigation--btn bold">More</button>
                                </div>
                            </div>
                        </div>
                    </div><!-- right -->
                </div>
            </div>
        </section>
    </FrontPage>
</template>