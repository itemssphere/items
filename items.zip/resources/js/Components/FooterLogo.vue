<template>
    <img src="/assets/img/svg/footer-logo.svg" alt="" class="footer__content--logo d-none d-lg-block">
</template>
