<template>
    <div class="header__search__bar">
            <div class="container">
                <div class="row">
                    <div class="col-12 d-lg-none">
                        <form class="m-header__search d-flex align-items-center justify-content-end">
                            <input type="text" placeholder="I want to buy…" class="m-header__search--input regular">
                            <div class="m-search-cancel"><img src="/assets/img/svg/header-btn/m-search-cancel.svg" alt=""></div>
                        </form>
                    </div>
                    <div class="col-12">
                        <div class="row">
                            <div class="col-lg-2">
                                <div class="header__search__bar--left d-flex flex-column align-items-end regular">
                                    Products (234)
                                    <a href="">View all</a>
                                </div>
                            </div>
                            <div class="col-lg-10">
                                <ul class="header__search__bar__list">
                                    <li class="header__search__bar__list--li">
                                        <a href="" class="header__search__bar__list--link d-flex align-items-center">
                                            <figure class="header__search__bar__list--img">
                                                <img src="/assets/img/headphone.png" alt="">
                                            </figure>
                                            <h1 class="header__search__bar__list--title regular">iPhone5 40 Inch 1080p  Smart LED Roku TV</h1>
                                        </a>
                                    </li>
                                    <li class="header__search__bar__list--li">
                                        <a href="" class="header__search__bar__list--link d-flex align-items-center">
                                            <figure class="header__search__bar__list--img">
                                                <img src="/assets/img/headphone.png" alt="">
                                            </figure>
                                            <h1 class="header__search__bar__list--title regular">iPhone5 40 Inch 1080p  Smart LED Roku TV</h1>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- end -->
                    <div class="col-12">
                        <div class="row">
                            <div class="col-lg-2">
                                <div class="header__search__bar--left d-flex flex-column align-items-end regular">
                                    Charities (56)
                                    <a href="">View all</a>
                                </div>
                            </div>
                            <div class="col-lg-10">
                                <ul class="header__search__bar__list">
                                    <li class="header__search__bar__list--li">
                                        <a href="" class="header__search__bar__list--link d-flex align-items-center">
                                            <figure class="header__search__bar__list--img">
                                                <img src="/assets/img/headphone.png" alt="">
                                            </figure>
                                            <h1 class="header__search__bar__list--title regular">iPhone5 40 Inch 1080p  Smart LED Roku TV</h1>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- end -->
                    <div class="col-12">
                        <div class="row">
                            <div class="col-lg-2">
                                <div class="header__search__bar--left d-flex flex-column align-items-end regular">
                                    News (2)
                                    <a href="">View all</a>
                                </div>
                            </div>
                            <div class="col-lg-10">
                                <ul class="header__search__bar__list">
                                    <li class="header__search__bar__list--li">
                                        <a href="" class="header__search__bar__list--link d-flex align-items-center">
                                            <h1 class="header__search__bar__list--title regular">iPhone5 40 Inch 1080p  Smart LED Roku TV</h1>
                                        </a>
                                    </li>
                                    <li class="header__search__bar__list--li">
                                        <a href="" class="header__search__bar__list--link d-flex align-items-center">
                                            <h1 class="header__search__bar__list--title regular">iPhone5 40 Inch 1080p  Smart LED Roku TV</h1>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div><!-- end -->
                </div>
            </div>
        </div>
</template>