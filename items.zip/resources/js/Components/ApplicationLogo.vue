<template>
    <div class="header__logo d-flex align-items-center">
        <img src="/assets/img/svg/header-logo.svg" alt="" class="header__logo--img">
    </div>
</template>
