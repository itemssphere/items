<template>
    <div class="mobile-categories">
        <div class="mobile-categories__head">
            <button class="mobile-categories__head--close">
                <img src="/assets/img/svg/clear-bold.svg" alt="">
            </button>
            <div class="d-flex justify-content-center">
                <img src="/assets/img/svg/popup-logo.svg" alt="">
            </div>
            <div class="mobile-categories__head--list">
                <a href="" class="mobile-categories__head--item active show">All Categories</a>
                <a href="" class="mobile-categories__head--item hide">მეორე</a>
                <a href="" class="mobile-categories__head--item hide">მესამე</a>
            </div>
        </div>
        <div>
            <ul class="mobile-categories__list mobile-categories__first">
                <li class="categories__list--item mobile-categories__first--item" data-id="0">
                    <a href="/about.html" class="categories__list--link regular">პირველი</a>
                </li>
                <li class="categories__list--item mobile-categories__first--item" data-id="1">
                    <a href="" class="categories__list--link regular">Auto & Transportation</a>
                </li>
                <li class="categories__list--item mobile-categories__first--item" data-id="2">
                    <a href="" class="categories__list--link regular">Clothing, Shoes & Accessories</a>
                </li>
                <li class="categories__list--item mobile-categories__first--item" data-id="3">
                    <a href="" class="categories__list--link regular">Packaging, Advertising & Office</a>
                </li>
                <li class="categories__list--item mobile-categories__first--item" data-id="4">
                    <a href="" class="categories__list--link regular">Agriculture & Food</a>
                </li>
            </ul>

            <div>
                <ul class="mobile-categories__list mobile-categories__second" data-id="0">
                    <li class="categories__list--item mobile-categories__second--item" data-id="0">
                        <a href="/about.html" class="categories__list--link regular">მეორეს ერთი</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="1">
                        <a href="" class="categories__list--link regular">Auto & Transportation</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="2">
                        <a href="" class="categories__list--link regular">Clothing, Shoes & Accessories</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="3">
                        <a href="" class="categories__list--link regular">Packaging, Advertising & Office</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="4">
                        <a href="" class="categories__list--link regular">Agriculture & Food</a>
                    </li>
                </ul>
                <ul class="mobile-categories__list mobile-categories__second" data-id="1">
                    <li class="categories__list--item mobile-categories__second--item" data-id="0">
                        <a href="/about.html" class="categories__list--link regular">მეორეს ორი</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="1">
                        <a href="" class="categories__list--link regular">Auto & Transportation</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="2">
                        <a href="" class="categories__list--link regular">Clothing, Shoes & Accessories</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="3">
                        <a href="" class="categories__list--link regular">Packaging, Advertising & Office</a>
                    </li>
                    <li class="categories__list--item mobile-categories__second--item" data-id="4">
                        <a href="" class="categories__list--link regular">Agriculture & Food</a>
                    </li>
                </ul>
            </div>

            <div>
                <ul class="mobile-categories__list mobile-categories__three" data-id="0">
                    <li class="categories__list--item mobile-categories__three--item" data-id="0">
                        <a href="/about.html" class="categories__list--link regular">მესამეს პირველი</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="1">
                        <a href="" class="categories__list--link regular">Auto & Transportation</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="2">
                        <a href="" class="categories__list--link regular">Clothing, Shoes & Accessories</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="3">
                        <a href="" class="categories__list--link regular">Packaging, Advertising & Office</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="4">
                        <a href="" class="categories__list--link regular">Agriculture & Food</a>
                    </li>
                </ul>
                <ul class="mobile-categories__list mobile-categories__three" data-id="1">
                    <li class="categories__list--item mobile-categories__three--item" data-id="0">
                        <a href="/about.html" class="categories__list--link regular">მესამეს მეორე</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="1">
                        <a href="" class="categories__list--link regular">Auto & Transportation</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="2">
                        <a href="" class="categories__list--link regular">Clothing, Shoes & Accessories</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="3">
                        <a href="" class="categories__list--link regular">Packaging, Advertising & Office</a>
                    </li>
                    <li class="categories__list--item mobile-categories__three--item" data-id="4">
                        <a href="" class="categories__list--link regular">Agriculture & Food</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</template>