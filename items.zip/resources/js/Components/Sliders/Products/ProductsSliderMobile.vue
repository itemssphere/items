<template>
    <div class="row d-flex d-lg-none">
        <div class="col-6">
            <div class="products-slider__item">
                <button class="products-slider__item--fav"><img src="assets/img/svg/product-fav.svg" alt=""></button>
                <!-- item slider -->
                <div class="item-slider__item">
                    <img src="assets/img/watch.png" alt="">
                </div>
                <div class="products-slider__item--footer d-flex flex-column align-items-start">
                    <div class="products-slider__item--status regular">
                        NEW
                    </div>
                    <div class="products-slider__item--price bold">
                        ₾1,239.39
                    </div>
                    <a href="" class="products-slider__item--name regular">
                        TCL 40S325 40 Inch 1080p Smart LED Roku TV
                    </a>
                    <div class="products-slider__item--stars regular d-flex align-items-center">
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item"></div>
                        <span>132 review</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="products-slider__item">
                <button class="products-slider__item--fav"><img src="assets/img/svg/product-fav.svg" alt=""></button>
                <!-- item slider -->
                <div class="item-slider__item">
                    <img src="assets/img/watch.png" alt="">
                </div>
                <div class="products-slider__item--footer d-flex flex-column align-items-start">
                    <div class="products-slider__item--status regular">
                        NEW
                    </div>
                    <div class="products-slider__item--price bold">
                        ₾1,239.39
                    </div>
                    <a href="" class="products-slider__item--name regular">
                        TCL 40S325 40 Inch 1080p Smart LED Roku TV
                    </a>
                    <div class="products-slider__item--stars regular d-flex align-items-center">
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item"></div>
                        <span>132 review</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="products-slider__item">
                <button class="products-slider__item--fav"><img src="assets/img/svg/product-fav.svg" alt=""></button>
                <!-- item slider -->
                <div class="item-slider__item">
                    <img src="assets/img/watch.png" alt="">
                </div>
                <div class="products-slider__item--footer d-flex flex-column align-items-start">
                    <div class="products-slider__item--status regular">
                        NEW
                    </div>
                    <div class="products-slider__item--price bold">
                        ₾1,239.39
                    </div>
                    <a href="" class="products-slider__item--name regular">
                        TCL 40S325 40 Inch 1080p Smart LED Roku TV
                    </a>
                    <div class="products-slider__item--stars regular d-flex align-items-center">
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item"></div>
                        <span>132 review</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="products-slider__item">
                <button class="products-slider__item--fav"><img src="assets/img/svg/product-fav.svg" alt=""></button>
                <!-- item slider -->
                <div class="item-slider__item">
                    <img src="assets/img/watch.png" alt="">
                </div>
                <div class="products-slider__item--footer d-flex flex-column align-items-start">
                    <div class="products-slider__item--status regular">
                        NEW
                    </div>
                    <div class="products-slider__item--price bold">
                        ₾1,239.39
                    </div>
                    <a href="" class="products-slider__item--name regular">
                        TCL 40S325 40 Inch 1080p Smart LED Roku TV
                    </a>
                    <div class="products-slider__item--stars regular d-flex align-items-center">
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item products-slider__item--stars--item--active"></div>
                        <div class="products-slider__item--stars--item"></div>
                        <span>132 review</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>