<?php
 
/** 
 *  File: Heading
 *  Locale: ge
 */
 
return [
    'title' => 'მართეთ თქვენი ქონება და შეიტანეთ წვლილი მდგრად განვითარებაში',
];