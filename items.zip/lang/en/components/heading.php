<?php
 
/** 
 *  File: Heading
 *  Locale: en
 */
 
return [
    'title' => 'Manage Your Property and Contribute to Sustainable Dvelopment',
];